# Easy-Inventory
Simple inventory management system build in Swing Java. It uses MySQL to store data. This can be use in small store and manage personal stuff.

###Layouts
![Main relative page](https://github.com/achyutdev/Easy-Inventory/blob/master/imgs/mainpage.JPG)

| ![Login relative page](https://github.com/achyutdev/Easy-Inventory/blob/master/imgs/loginpage.JPG)  | ![Update page](https://github.com/achyutdev/Easy-Inventory/blob/master/imgs/additem.JPG)
|-------------|---------------:
