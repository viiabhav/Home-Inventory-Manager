package easy.util;

public class EasyConstant {
    public static final String INSERT_PRODUCT_QUERY = "INSERT INTO products  ( `tag`, `name`, `company`, `cost_price`,`selling_price`,`profit`, `status`)  VALUES (?,?,?,?,?,?,?)";

}
